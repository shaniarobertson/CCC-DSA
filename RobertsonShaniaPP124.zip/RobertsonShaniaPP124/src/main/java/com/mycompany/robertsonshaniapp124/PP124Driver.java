/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.robertsonshaniapp124;

import java.util.Scanner;

/**
 * Driver for ArrayStack.java
 * 
 * Also fixed exception handling for Peek and Pop when stack is empty.
 * 
 * @author Shania
 */
public class PP124Driver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayStack<String> stk = new ArrayStack<String>();
        
        int menu = 0;
        System.out.println("Top of the stack points to the top element, not next available location.");
        do{
            try {
            System.out.println("""
                               Stack Menu Selections
                               1.Push 
                               2.Pop 
                               3.Peek
                               4.Display 
                               5.Exit""");
            System.out.println("");
            System.out.println("Enter Menu Number:");
            menu = Integer.parseInt(input.next());
            switch (menu) {
                case 1:
                    System.out.println("Enter element: ");
                    String element = input.next();
                    stk.push(element);
                    break;
                case 2:
                    System.out.println("Popped element is " + stk.pop());
                    break;
                case 3:
                    String peek = stk.peek();
                    System.out.println("Top element is " + peek);
                    break;
                case 4:
                    System.out.println("Displaying stack elements: ");
                    stk.display();
                    break;
                case 5:
                    return;
                }
            } catch (EmptyCollectionException ex) {
                System.out.println("**************************");
                System.out.println("Stack is Empty. Try again.");
                System.out.println("**************************");
                System.out.println("");
            }
            System.out.println("----------------------");
        }while(true);
    } 
}
