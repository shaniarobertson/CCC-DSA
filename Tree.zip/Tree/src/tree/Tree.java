/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tree;

/**
 * Tree Traversal Program
 * @author Shania Robertson
 */
public class Tree {

    static class Node {
        char value;
        Node left, right;
        
            Node(char value) {
                this.value = value;
                left = null;
                right = null;
            }
    }
    
    /*
     * Insert values into the tree based on whether the value is greater than or 
     * less than the value of the parent node
     */
    public void insert(Node node, char value) {
        if (value < node.value) { // if value less than node (and not null), insert left
            if (node.left != null) { 
                insert(node.left, value); 
            } else { 
                System.out.println(" Inserted " + value + " to left of " + node.value); 
                node.left = new Node(value); 
            } 
        } else if (value > node.value) { // if value greater than node (and not null), insert right
          if (node.right != null) {
            insert(node.right, value);
          } else {
            System.out.println("  Inserted " + value + " to right of "
                + node.value);
            node.right = new Node(value);
          }
        }
      }
    
    /*
     * Traverse the tree InOrder meaning:
     *  Traverse the left subtree,
     *  then visit the root, 
     *  then traverse the right subtree
     */
    public void traverseInOrder(Node node) {
        if (node != null) {
            traverseInOrder(node.left);
            System.out.print(" " + node.value);
            traverseInOrder(node.right);
        }
     }
   
    /*
     * Traverse the tree PostOrder meaning:
     *  Traverse the subtrees from left to right,
     *  then visit the root 
     */
    public void traversePostOrder(Node node) {
        if (node != null) {
            traversePostOrder(node.left);
            traversePostOrder(node.right);
            System.out.print(" " + node.value);
        }
    }
    
    /*
     * Calculate the height of the tree
     * Used for traversing the tree LevelOrder
     */
    private static int height(Node node){
        if (node == null) {
            return 0;
        } else {
            
            int leftheight = height(node.left);
            int rightheight = height(node.right);
 
            
            if (leftheight > rightheight) {
                return (leftheight + 1);
            }else {
                return (rightheight + 1);
            }
        }
    }
 
    /*
     * Traverse the current level of the tree 
     */
    public void currentLevel(Node node, int level) {
    if (node == null) // if null, return
            return;
        if (level == 1) // if first level, return the node (root)
            System.out.print(node.value + " ");
        else if (level > 1) { //if level above 1, 
            currentLevel(node.left, level - 1);
            currentLevel(node.right, level - 1);
        }
    }
    
    /*
     * Traverse the tree LevelOrder meaning:
     *  Visit each node at each level of the tree from top (root)
     *  to bottom, and left to right 
     */
    public void traverseLevelOrder (Node node) {
        int h = height(node);
        for (int i = 1; i <= h; i++){ // traverse each individual level of the tree
            currentLevel(node, i);
        }
    }
    
    /*
     * Traverse the tree PreOrder meaning:
     *  Visit the root,
     *  then traverse the subtrees from left to right 
     */
    public void traversePreOrder(Node node) {
        if (node != null) {
            System.out.print(" " + node.value);
            traversePreOrder(node.left);
            traversePreOrder(node.right);
        }
    }

    
    public static void main(String[] args) {
        Tree tree = new Tree();
            Node root = new Node ('a');
            System.out.println("Binary Tree Example");
            System.out.println("Building tree with root value " + root.value);
            tree.insert(root, 'D');
            tree.insert(root, 'h');
            tree.insert(root, 'e');
            tree.insert(root, 'i');
            tree.insert(root, 'k');
            tree.insert(root, 'F');
            tree.insert(root, 'B');
            tree.insert(root, 'A');
            tree.insert(root, 'C');
            tree.insert(root, 'c');
            tree.insert(root, 'G');
            
            System.out.println("Traversing tree in order");
            tree.traverseInOrder(root);
            System.out.println("");
            System.out.println("Traversing tree post order");
            tree.traversePostOrder(root);
            System.out.println("");
            System.out.println("Traversing tree level order @ height 4");
            tree.traverseLevelOrder(root);
            System.out.println("");
            System.out.println("Traversing tree preorder");
            tree.traversePreOrder(root);
            System.out.println("");
    }
    
}
