/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsjf;

import java.util.Scanner;
import jsjf.exceptions.EmptyCollectionException;

/**
 *
 * @author Shania
 */
public class LinkedListDriver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        LinkedOrderedList<String> list = new LinkedOrderedList<>();
             
        int menu = 0;
        String element;
 
        do {
            try {
                System.out.println("Linked List Selections: " + 
                        "1.add element | 2.remove element | 3.head element | "
                        + "4.display | 5.exit");
                menu = Integer.parseInt(input.next());
                switch (menu){
                    case 1: // add element
                        System.out.println("Enter element: ");
                        element = input.next();
                        list.add(element);
                        break;
                    case 2: // remove element
                        System.out.println("Enter element: ");
                        element = input.next();
                        list.remove(element);
                        System.out.println(element + " removed.");
                        break;
                    case 3: // head element
                        String first = list.first();
                        System.out.println("First element in LinkedOrderedList is " + first );
                        break;
                    case 4: // display
                        System.out.println(list);
                        break;
                    case 5:
                        return;
                }
            } catch (EmptyCollectionException ex) {
                System.out.println("ArrayList is empty.");
            }
        } while(menu <= 5);
    }
}
