/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp18.pkg1;

/**
 *
 * @author Shania
 */
public class PP181 {

    /**
     * Sorts the specified array of objects using a bubble sort
     * algorithm.
     *
     * @param <T>
     * @param data the array to be sorted
     */
    public static <T extends Comparable<T>> 
      void bubbleSort(T[] data) {
        int position, scan;
        boolean sorted = false; //array not sorted
        int pass = 0; //count passes for tracers
       
        for (position =  data.length - 1; position >= 0; position--){
            pass++; //tracer iteration
            System.out.println("Prior to pass " + pass + ". Sorted = " + sorted); //tracer
            for (scan = 0; scan <= position - 1; scan++){
                if (data[scan].compareTo(data[scan + 1]) > 0){
                    swap(data, scan, scan + 1);
                    sorted = false; //if swap occurs, array not sorted
                } else {
                    sorted = true; //swap did not occur, array sorted
                }
            }
            System.out.println("End of pass " + pass + ". Sorted = " + sorted); //tracer
            if (sorted)
                return; //if array is sorted, end
            }
        }



    /**
     * Swaps to elements in an array. Used by various sorting algorithms.
     * 
     * @param data   the array in which the elements are swapped
     * @param index1 the index of the first element to be swapped
     * @param index2 the index of the second element to be swapped
     */
    private static <T extends Comparable<T>> 
      void swap(T[] data, int index1, int index2) {
	T temp = data[index1];
	data[index1] = data[index2];
	data[index2] = temp;
    }
}
