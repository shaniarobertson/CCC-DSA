/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsjf;

import java.util.Scanner;
import jsjf.exceptions.EmptyCollectionException;

/**
 *
 * @author shaniarobertson
 */
public class ArrayListDriver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<String> list = new ArrayUnorderedList<>();

        int menu = 0;
        String element;

        do {
            try {
                System.out.println("Array List Selections: " + 
                        "1.add element | 2.remove element | 3.first element | "
                        + "4.last element | 5.display | 6.exit");
                menu = Integer.parseInt(input.next());
                switch (menu){
                    case 1: // add element
                        System.out.println("Enter element: ");
                        element = input.next();
                        list.add(element);
                        break;
                    case 2: // remove element
                        System.out.println("Enter element to remove: ");
                        element = input.next();
                        list.remove(element);
                        System.out.println(element + " removed.");
                        break;
                    case 3: // first element
                        String first = list.first();
                        System.out.println("First element in ArrayList is " + first );
                        break;
                    case 4: // last element
                        String last = list.last();
                        System.out.println("Last element in ArrayList is " + last);
                        break;
                    case 5: // display
                        System.out.println(list);
                        break;
                    case 6:
                        return;
                }
            } catch (EmptyCollectionException ex) {
                System.out.println("ArrayList is empty.");
            }
        } while(menu <= 5 );

    }
}