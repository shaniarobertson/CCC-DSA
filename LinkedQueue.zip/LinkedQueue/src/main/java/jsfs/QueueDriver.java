/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsfs;

import java.util.Scanner;
import jsjf.exceptions.EmptyCollectionException;

 /**
  *Application is a queue that enqueues, dequeues,shows first element, displays a list 
  * User enters in elements and picks options to perform them
  * @author Sienna Nguyen
  * Version: 1.0
  * Date: 10/2/2021
  */
public class QueueDriver {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        LinkedQueue<String> queue = new LinkedQueue<String>();
        
        int menu = 0;
        do{
            try{
            System.out.println("\nQueue Menu Selections: 1.Enqueue | 2.Dequeue | 3.first | 4.list | 5.Exit");
            System.out.println();
                        //Asking user to enter choice
            System.out.println("Enter menu choice: ");
            menu=Integer.parseInt(input.next());
            switch(menu){
                case 1:
                    System.out.println("Enter element: ");
                    String element=input.nextLine();
                    element = input.nextLine();
                    queue.enqueue(element);
                    break;
                case 2:
                    System.out.println("Dequeued element is: " + queue.dequeue());
                    break;
                case 3:
                    System.out.println("First element in the queue is: " + queue.first());
                    break;
                case 4:
                    System.out.println("Elements on the queue: ");
                    queue.list();
                    break;
                case 5:
                    System.exit(0);
                    return;
            }
            }catch(EmptyCollectionException ex){
                System.out.println("Queue is empty");
            }
        }while(menu!=0);
    }
}
