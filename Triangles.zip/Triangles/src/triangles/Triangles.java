/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package triangles;
import java.util.Scanner;

/**
 * Program that calculates the area and perimeter for valid triangles.
 * @author Shania
 */
public class Triangles {
    
    private float sA, sB, sC;
    
    /*
        If the triangle has three valid sides,
        Calculates s (half of the perim), perimeter, and area for the given triangle.
        Calls getInput() to loop recursively.
    */
    public void triangles(float sA, float sB, float sC) {
        float s = ((sA + sB + sC)/2);
        float area = (float) Math.pow((s * (s - sA) * (s - sB) * (s - sC)), .5);
        float perimeter = (sA + sB + sC);
        
        if (sA + sB <= sC || sC + sB <= sA || sC + sA <= sB) {
            getInput();
        }else {
            System.out.println(sA + ", " + sB + ", " + sC);
            System.out.println("Perimeter: " + perimeter);
            System.out.println("Area: " + area);
            getInput();
        }
    }
    
    /*
        Get input for triangle parameters from the user and validate it.
        Program ends if sA is negative.
    */
    public void getInput() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter three valid triangle sides: ");
        System.out.println("Enter -1 to exit: ");
        sA = input.nextFloat();
        sB = input.nextFloat();
        sC = input.nextFloat();
        
        if (sA > 0) {
            triangles(sA, sB, sC);
        }
    }
}

