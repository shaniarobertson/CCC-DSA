/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package triangles;

import java.util.Scanner;
/**
 * Driver for Triangles
 * @author Shania
 */
public class TrianglesDriver {

    public static void main(String[] args) {
        Triangles triangles = new Triangles();
        triangles.getInput();
    }
}
