/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.linkedqueueproject;

import java.util.Scanner;
/**
 * Driver for LinkedQueue.java
 * 
 * @author Shania Robertson
 */
public class LinkedQueueDriver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        LinkedQueue<String> q = new LinkedQueue<>();
        
        int menu = 0;
 
        do {
            try {
                System.out.println("Queue Menu Selections: " + 
                        "1.enqueue | 2.dequeue | 3.first | 4.list | 5.exit");
                menu = Integer.parseInt(input.next());
                switch (menu){
                    case 1:
                        System.out.println("Enter element: ");
                        String element = input.nextLine();
                        element = input.nextLine();
                        q.enqueue(element);
                        break;
                    case 2:
                        System.out.println("Dequeued element is " + q.dequeue());
                        break;
                    case 3:
                        String first = q.first();
                        System.out.println("First element in queue is " + first);
                        break;
                    case 4:
                        System.out.println("Elements on the queue: ");
                        q.list();
                        break;
                    case 5:
                        return;
                }
            } catch (EmptyCollectionException ex) {
                System.out.println("Queue is empty.");
            }
        } while(true);
    }
}
