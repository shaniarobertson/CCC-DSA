package postfixevaluator;

import jsjf.*;
import java.util.StringTokenizer;


/**
 * PostfixEvaluator this modification of our stack example uses a 
 * stack to create an expression tree from a VALID integer postfix expression 
 * and then uses a recursive method from the ExpressionTree class to 
 * evaluate the tree.
 * 
 * @author Java Foundations
 * @version 4.0
 */
public class PostfixEvaluator    
{
        private final char ADD = '+', SUBTRACT = '-';
	private final char MULTIPLY = '*', DIVIDE = '/', POW = '^';

        private LinkedStack<Double> stk;
        
	/**
	 * Sets up this evaluator by creating a new stack.
	 */
	public PostfixEvaluator()
	{
            stk = new LinkedStack<>();
	}

        /**
	 * Evaluates the specified postfix expression by tokenizing a string
	 * expression and appropriately pushing/popping the values depending
	 * on whether the token is an operator or not.
	 * @param expression string representation of a postfix expression
	 * @return value of the given expression
	 */
	public double evaluate(String expression)
	{
            double op1, op2;
            double result = 0;
            String token;
            StringTokenizer tokenizer = new StringTokenizer(expression);

            while (tokenizer.hasMoreTokens()) 
            {
                token = tokenizer.nextToken();
                if (isOperator(token)) {
                    op2 = stk.pop();
                    op1 = stk.pop();
                    result = evalSingleOp(token.charAt(0), op1, op2);
                    stk.push(result);
                } else {
                    result = Double.parseDouble(token);
                    stk.push(result);
                }
            }
            return result;        
	}

         /*
          * Determines if the specified token is an operator.
          */
        private boolean isOperator(String token) 
        {
            return (token.equals("+")|| token.equals("-") ||
                    token.equals("*")) || token.equals("/")
                     || token.equals("^");
        }
        
        /*
         * Performs specified operation depending on the value of the char  
         */
        private double evalSingleOp(char operation, double op1, double op2) 
        {
            double result = 0;
            
		switch (operation) {
                    case ADD:
			result = op1 + op2;
			break;
                    case SUBTRACT:
			result = op1 - op2;
			break;
                    case MULTIPLY:
			result = op1 * op2;
			break;
                    case DIVIDE:
			result = op1 / op2;
			break;
                    case POW:
			result = Math.pow(op1, op2);
		}

		return result; 
        }
        
	

       

}
